//
//  ViewController.swift
//  textfieldvalidation
//
//  Created by MACOS on 11/25/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit


let  REGEX_USER_NAME_LIMIT = "^.{3,10}$"
 let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}"
let  REGEX_EMAIL =  "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
let REGEX_PASSWORD_LIMIT = "^.{6,20}$"
let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}"
let REGEX_PHONE_DEFAULT = "[0-9]{10}"

class ViewController: UIViewController {

    
    @IBOutlet weak var txtusername:  TextFieldValidator!
    
    
    @IBOutlet weak var txtpassword: TextFieldValidator!
    
    @IBOutlet weak var txtemail: TextFieldValidator!
    
    @IBOutlet weak var txtmob: TextFieldValidator!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setvalidate();
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func setvalidate() {
        
        txtusername.addRegx(REGEX_USER_NAME, withMsg: "username limite should be 3 to 10 char")
        txtusername.presentInView = self.view;
        
        txtpassword.addRegx(REGEX_PASSWORD, withMsg: "password limite should be 6 to 20 char")
        txtpassword.presentInView = self.view;
        
        txtemail.addRegx(REGEX_EMAIL, withMsg: "email address is wrong")
        
        txtemail.presentInView = self.view;
        
        txtmob.addRegx(REGEX_PHONE_DEFAULT, withMsg: "enter valid mob ")
        txtmob.presentInView = self.view;
        
        
    }
    @IBAction func btnaction(_ sender: AnyObject) {
    
        if txtusername.validate() && txtpassword.validate() && txtemail.validate() && txtmob.validate() {
            
            print("successfull ");
            
            //write the code for navigation to another page 
            
            
        }
        else
        {
            
        }
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

